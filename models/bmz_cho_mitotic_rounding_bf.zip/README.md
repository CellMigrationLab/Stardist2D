# CHO mitotic rounding (brightfield): StarDist 2D model

From the BioImage Model Zoo entry 'sincere-microbe' (CHO mitotic rounding segmentation - brightfield - StarDist), by Estibaliz Gómez de Mariscal, Mario Del Rosario. Licence: MIT (keep this notice).

Files: config.json and thresholds.json from the entry's rdf.yaml (config.stardist); weights_best.h5 is its stardist_weights.h5, unchanged.
