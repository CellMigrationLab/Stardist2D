# Fluorescent cells: StarDist 2D model

From the Zenodo record StarDist_Fluorescent_cells (doi:10.5281/zenodo.10572310), 2024-01-26, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `StarDist_Fluorescent_cells_OK/StarDist Model` in `StarDist_Fluorescent_cells.zip` (unchanged).
