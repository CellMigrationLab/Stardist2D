# AsPC1 cells (Lifeact): StarDist 2D model

From the Zenodo record StarDist_AsPC1_Lifeact (doi:10.5281/zenodo.13442128), 2024-08-29, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `Stardist_AsPC1_from _TC/231222_stardist_AsPC1_from _TC-ch_MODEL` in `Stardist_AsPC1_from _TC.zip` (unchanged).
