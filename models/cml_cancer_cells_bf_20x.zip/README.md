# Cancer cells 20x (brightfield): StarDist 2D model

From the Zenodo record StarDist_BF_cancer_cell_dataset_20x (doi:10.5281/zenodo.10572122), 2024-01-26, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `StarDist_BF_Cancer_cell_dataset_OK/Stardist_CancerCells_model` in `StarDist_BF_Cancer_cell_dataset.zip` (unchanged).
