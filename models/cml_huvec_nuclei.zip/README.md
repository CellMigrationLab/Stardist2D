# HUVEC nuclei (fluorescence): StarDist 2D model

From the Zenodo record StarDist_HUVEC_nuclei_dataset (doi:10.5281/zenodo.10617532), 2024-02-05, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `StarDist_HUVEC_nuclei_dataset_OK/210916_stardist_HUVEC_nuclei_model` in `StarDist_HUVEC_nuclei_dataset.zip` (unchanged).
