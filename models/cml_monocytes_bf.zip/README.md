# Monocytes (brightfield): StarDist 2D model

From the Zenodo record StarDist_BF_Monocytes_dataset (doi:10.5281/zenodo.10572200), 2024-01-26, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `StarDist_BF_Monocytes_dataset_OK/Stardist_Monocytes_model` in `StarDist_BF_Monocytes_dataset.zip` (unchanged).
