# Tumour cell nuclei (DAPI): StarDist 2D model

From the Zenodo record StarDist_TumorCell_nuclei (doi:10.5281/zenodo.13443221), 2024-08-29, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `Stardist_TCs_nuclei_DAPI/231027_Stardist_TCs_nuclei_DAPI-ch_MODEL` in `Stardist_TCs_nuclei_DAPI.zip` (unchanged).
