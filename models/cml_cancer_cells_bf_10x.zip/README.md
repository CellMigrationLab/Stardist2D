# Cancer cells 10x (brightfield): StarDist 2D model

From the Zenodo record StarDist_BF_cancer_cell_dataset_10x (doi:10.5281/zenodo.13304399), 2024-08-12, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `StarDist_BF10x_Cancer_cell_dataset/StarDist_model` in `StarDist_BF10x_Cancer_cell_dataset.zip` (unchanged).
