# MiaPaCa2 cells (CD44): StarDist 2D model

From the Zenodo record Stardist_MiaPaCa2_from_CD44 (doi:10.5281/zenodo.13442877), 2024-08-29, by Follain, Gautier, Ghimire, Sujan, Pylvänäinen, Joanna, Ivaska, Johanna, Jacquemet, Guillaume.
Licence: cc-by-4.0 (attribution required: cite the record above).

Files: config.json, thresholds.json, weights_best.h5 from `Stardist_MiaPaCa2_from_CD44/240116_Stardist_MiaPaCa2_from_CD44_ch_MODEL` in `Stardist_MiaPaCa2_from_CD44.zip` (unchanged).
